import java.util.Scanner;
public class midterm{
public static void main(String[] args){
	System.out.println("Welcome to the menu!");
	System.out.println("1: gross pay calculator");
	System.out.println("2: subscription package");
	System.out.println("3: fibonacci sequence");
	
	int userInput = 0;
	
	do{
	System.out.println("Choose 1, 2, or 3 for");
	System.out.println("the programs");
	Scanner in1 = new Scanner(System.in);
	userInput = in1.nextInt();
	if (userInput < 1 || userInput > 3){
		System.exit(0);
	
	switch(userInput){
	case 1:
	System.out.println("Hours worked?");
	int hours = 0
	Scanner in = new Scanner(System.in);
	hours = in.nextInt();
	System.out.println("Pay rate?");
	int payRate = 0;
	payRate = in.nextInt();
	int grossPay = 0;
	
	if (hours >= 20 && hours < 40){
	payRate = payRate * 2;
	}
	if (hours >= 40){
	payRate = payRate * 3;
	}
	grossPay = payRate * hours;
	System.out.println("Gross pay is: " + grossPay);
	break;
	
	case 2:
	System.out.println("Choose a subscription package:");
	System.out.println("1: 30 a month, 11 hours, $3 for additional");
	System.out.println("hrs up to 22 hrs then $6 after");
	System.out.println("2: 35 a month, 22 hours, $2 for additional");
	System.out.println("hrs up to 44 hrs then $4 after");
	System.out.println("3: 40 a month, 33 hours, $1 for additional");
	System.out.println("hrs up to 66 hrs then $2 after");
	Scanner in = new Scanner(System.in);
	int userInput = in.nextInt();
	int hourUsage = 0;
	int monthlyCharge = 0;
	switch(userInput){
	case 1:
	System.out.println("What is your hourly usage?");
	Scanner in = new Scanner(System.in);
	hourUsage = in.nextInt();
	if (hourUsage > 11 && hourUsage <= 22){
	hourUsage = (hourUsage - 11) * 3;
	}
	else if (hourUsage > 22){
	hourUsage = (hourUsage - 22) * 6 + 33;
	}
	monthlyCharge = hourUsage + 30;
	System.out.println("Total monthly charge is:");
	System.out.println(monthylCharge);
	break;
	
	case 2:
	System.out.println("What is your hourly usage?");
	Scanner in = new Scanner(System.in);
	hourUsage = in.nextInt();
	if (hourUsage > 22 && hourUsage <= 44){
	hourUsage = (hourUsage - 22) * 2;
	}
	else if (hourUsage > 44){
	hourUsage = (hourUsage - 44) * 4 + 44;
	}
	monthlyCharge = hourUsage + 35;
	System.out.println("Total monthly charge is:");
	System.out.println(monthylCharge);
	break;
	
	case 3:
	System.out.println("What is your hourly usage?");
	Scanner in = new Scanner(System.in);
	hourUsage = in.nextInt();
	if (hourUsage > 33 && hourUsage <= 66){
	hourUsage = (hourUsage - 33) * 1;
	}
	else if (hourUsage > 66){
	hourUsage = (hourUsage - 66) * 2 + 33;
	}
	monthlyCharge = hourUsage + 40;
	System.out.println("Total monthly charge is:");
	System.out.println(monthylCharge);
	break;
break;

	case 3:
	System.out.println("Enter a fibonacci sequence number: ");
	int fibInt = 0;
	int userInt = 0;
	Scanner in = new Scanner(System.in);
	userInt = in.nextInt();
	fibInt = userInt - 2 + userInt - 1;
	System.out.println("Fibonacci number: ");
	System.out.println(fibInt);
	break;
	
	}while (userInput >= 1 || userInput <= 3);
	
	
	
	
	